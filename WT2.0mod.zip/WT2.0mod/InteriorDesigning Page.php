<?php
	session_start();?>
<html>
<link rel="stylesheet" type="text/css" href="SideMenuBar.css"/>
<link rel="stylesheet" type="text/css" href="MainMenuBar.css"/>
<link rel="stylesheet" type="text/css" href="MovingText.css"/>
<link rel="script" type="text/script" href="MainMenu & SideMenu.js"/>
	<head><title>Interior Designing</title>
    <style>
		::-webkit-scrollbar {
	    display: none;
	}
    body{
      font-family: "Lato", sans-serif;
      background-color: black;
      background-repeat:no-repeat;
      background-size:100%;
      background-attachment: fixed;
      }

      .button {
        display: inline-block;
        border-radius: 15px 0px 15px 15px;
        background-color: rgb(26, 82, 118  );
        border: none;
        color: #FFFFFF;
        text-align: center;
        float: right;
        font-size: 20px;
        padding: 1px;
        height: 50px;
        width: 15%;
        transition: all 0.5s;
        cursor: pointer;
        margin: 5px;
      }

      .button span {
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
      }

      .button span:after {
        content: '...';
        position: absolute;
        opacity: 0;
        top: 0;
        right: -30px;
        transition: 0.5s;
      }

      .button:hover span {
        padding-right: 25px;
      }

      .button:hover span:after {
        opacity: 1;
        right: 0;
      }
  /*--------------------------------------------------------------------------*/

      .headings {
        padding-left: 20px;
        color: white;
        font-family: Comic Sans MS;
        font-size: 24px;
        text-shadow: 0 0 3px rgb(72,201,176);
      }
      .heading_divs {
        height: auto;
        width: 100%;
        padding: 10px;
        background-color: rgb(127, 140, 141);
        border-radius: 20px;
      }

      .heading_divs_img {
        margin-left: 5px;
        border: 1px solid black;
      }

      .heading_divs_img:hover {
        cursor: pointer;
        opacity: 0.8;
      }

  /*--------------------------------------------------------------------------*/
      .buttonPressedEffect {
        padding: 2px 10px;
        cursor: pointer;
        text-align: center;
        text-decoration: none;
        outline: none;
        color: #fff;
        background-color: rgb(72,201,176);
        border: none;
        border-radius: 15px;
        box-shadow: 0 3px #999;
      }

      .buttonPressedEffect:hover {background-color: #3e8e41}

      .buttonPressedEffect:active {
        background-color: #3e8e41;
        box-shadow: 1px 1px #666;
        transform: translateY(4px);
      }

  /*--------------------------------------------------------------------------*/

      .LoginPopup {
          display: none; /* Hidden by default */
          position: fixed; /* Stay in place */
          z-index: 1; /* Sit on top */
          padding-top: 100px; /* Location of the box */
          left: 0;
          top: 0;
          width: 100%; /* Full width */
          height: 100%; /* Full height */
          overflow: auto; /* Enable scroll if needed */
          background-color: rgb(0,0,0); /* Fallback color */
          background-color: rgba(0,0,0,0.5); /* Black w/ opacity */
      }

      .LoginPopup-content {
          position: relative;
          background-color: #fefefe;
          border-radius: 25px 25px 0px 25px;
          margin: auto;
          padding: 0;
          border: 1px solid #888;
          width: 80%;
          box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
          -webkit-animation-name: animatetop;
          -webkit-animation-duration: 0.6s;
          animation-name: animatetop;
          animation-duration: 0.6s
      }
      @-webkit-keyframes animatetop {
          from {top:-300px; opacity:0}
          to {top:0; opacity:1}
      }

      @keyframes animatetop {
          from {top:-300px; opacity:0}
          to {top:0; opacity:1}
      }
      .close {
          color: white;
          float: right;
          font-size: 28px;
          font-weight: bold;
      }

      .close:hover,
      .close:focus {
          color: #000;
          text-decoration: none;
          cursor: pointer;
      }

      .LoginPopup-header {
          border-radius: 25px 25px 0px 0px;
          padding: 2px 16px;
          background-color: rgb(26, 82, 118  );
          color: white;
      }

      .LoginPopup-body {
          border-radius: 0px;
          padding: 20px;
      }

  /*--------------------------------------------------------------------------*/


      div.moving_text {
        font-family:"Ordnung";;
        font-weight: bold;
        font-size: 27px;
        width: 190px;
        position: relative;
        -webkit-animation: MoveLogoText 5s infinite;
        animation: MoveLogoText 20s infinite;
        animation-timing-function: linear;
      }

      @keyframes MoveLogoText {
        from {left: -190px;}
        to {left: 100%;}
        0%   { color: orange;}
        25%  { color: white;}
        50%  { color: blue;}
        75%  { color: white;}
        100% { color: green;}
      }

      div.moving_text:hover {
        animation-play-state: paused;
      }
  /*--------------------------------------------------------------------------*/

      #SigninPageOpener:hover {
        cursor: pointer;
      }
			#view_img{
				display:none; /* Hidden by default */
				position: fixed; /* Stay in place */
				z-index: 2; /* Sit on top */
				box-sizing: border-box;
				margin:  0 ;
				padding: 0 10% 0 10%;
				left: 0;
				top: 0;
				width: 100%; /* Full width */
				height: 100%; /* Full height */
				overflow: auto; /* Enable scroll if needed */
				background-color: rgb(0,0,0); /* Fallback color */
				background-color: rgba(0,0,0,0.8); /* Black w/ opacity */
			}
    </style>
		<script>
			var i=1;
			var j=0;
			var StatusNumber="";
			function update()
			{
				document.getElementById("fb").style.color="Blue";
				document.getElementById("fb").style.border="Black";
				var newStatus = document.createElement("div");
				newStatus.style.border = "1px solid green";
				newStatus.style.margin = "10px";
				newStatus.style.width = "50%";
				newStatus.style.borderRadius = "20px";
				newStatus.style.padding = "5px 10px 5px 20px";
				newStatus.style.background = "rgba(240,240,240,0.4)";
				StatusNumber="fb"+ i;
				newStatus.setAttribute("id", StatusNumber);

				var message=prompt("Your Query Please:");
        if(message == null)
          console.log("Update Cancelled");
        else if(message == "")
          alert("You Entered An Empty Status! It won't be displayed");
        else
        {
    				newStatus.innerHTML = "<p>#"+i+".&nbsp&nbsp&nbsp&nbsp"+message+"</p>";

    				newStatus.style.color = "White";
    				var container = document.getElementById("container");
    				container.appendChild(newStatus);
    				i++;

    				var br = document.createElement("br");
    				newStatus.appendChild(br);

    				var like = document.createElement("button");
    				like.innerHTML="Like ";
    				var likeCount = document.createElement("span");
    				likeCount.value=0;
    				like.appendChild(likeCount);

    				like.onclick = function()
    				{
    					var LC=likeCount.value;
    					likeCount.value=LC+1;
    					likeCount.innerHTML= (LC+1);
    				};

    				var comment = document.createElement("button");
    				comment.innerHTML="Comment"
    				comment.onclick=function()
    				{
    					var commentText=prompt("enter the comment");
              if(commentText == null)
                console.log("Commenting Cancelled");
              else if(commentText == "")
                alert("You Entered An Empty Comment! It won't be displayed");
              else
              {
        					var commentArea = document.createElement("p");
        					commentArea.innerHTML="&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"+commentText+"\t";
        					newStatus.appendChild(commentArea);

        					var deletecommentText= document.createElement("button");
        					deletecommentText.innerHTML="delete";
        					commentArea.appendChild(deletecommentText);
        					deletecommentText.onclick=function()
        					{
        						newStatus.removeChild(commentArea);
        					}

        					var reply=document.createElement ("button");
        					reply.innerHTML="reply";
        					commentArea.appendChild(reply);
        					reply.onclick=function()
        					{
        						var reply=prompt("Enter your reply:");
                    if(reply == null)
                      console.log("Replying Cancelled");
                    else if(reply == "")
                      alert("You Entered An Empty Reply! It won't be displayed");
                    else
                    {
          						var replyArea= document.createElement ("p");
          						replyArea.innerHTML="&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp"+reply;
          						commentArea.appendChild(replyArea);
                    }
        					}
              }
    				}


    				newStatus.appendChild(like);
    				newStatus.appendChild(comment);

    				var delete1= document.createElement ("button");
    				delete1.innerHTML="delete";


    				delete1.onclick=function()
    				{
    					container.removeChild(newStatus);
    				}
    				newStatus.appendChild(delete1);
						var vbut = document.createElement('button');
						vbut.innerHTML='view';
						vbut.setAttribute("onclick","view(event)");
						newStatus.appendChild(vbut);
			 }
    }
		/*view_img*/
		function set_imgsize(){
			var a = document.getElementById('view_img');
			var b = a.getElementsByTagName('img');
			for(var i = 0;i<b.length;++i){
				b[i].style.display='inline-block';
				b[i].style.width='45%';
				b[i].style.height='45%';
				b[i].style.margin='2%';
			}
		}
		function view(e) {
			document.querySelector('#view_img').style.display='block';
			upd_img(e);
		}
		function upd_img(e){

		}
		</script>
	</head>

	<body onload="set_imgsize()">
    <div class="menubartype">
      <ul class="menubar">
        <li class="menubar_li"><a class="menubar_li_a" href="WTproject.php">HOME</a></li>
        <li class="menubar_li"><a class="menubar_li_a" id="mainMenuProfile">PROFILE</a></li>
        <!--<button id="myBtn" class="button" style="vertical-align:middle"><span>PROFILE</span></button>-->
        <li class="menubar_li"><a class="menubar_li_a" href="3D Trekking.html">CONTACT</a></li>
        <li class="menubar_li"><a class="menubar_li_a" href="aboutPage.html">ABOUT</a></li>
      </ul>
    </div>
    <!-------------------------------------------------------------------------->

    	<div class="moving_text">PictoBlog</div>

    	<div id="myLoginPopup" class="LoginPopup">
    		<!-- LoginPopup content -->
    		<div class="LoginPopup-content">
    			<div class="LoginPopup-header">
    				<span class="close" style="cursor: pointer;">x</span>
    				<h2 style="text-align:center;">LOGIN</h2>
    			</div>
    			<div class="LoginPopup-body">
    				<!--<table style="padding-top: 3%; padding-bottom:3%; padding-left:20%">
    					<form action="" method="post">
    							<tr>
    								<td style="padding-right: 50px;">USERNAME</td><td><input type="text" name="username" size="25" maxlength="20" placeholder="required" style="font-size:12pt;height:25px;width:200px;" required/></td>
    							</tr>
    							<tr>
    								<td style="padding-right: 50px;">PASSWORD</td><td><input type="password" name="password" size="25" maxlength="20" placeholder="required" style="font-size:12pt;height:25px;width:200px;" required/></td><td style="padding-left: 50px;"><a style="font-size: 0.5em;" href="">Forgot Password?</a></td>
    							</tr>
    							<tr><td style="padding-top: 25px;"><input type="submit" class="buttonPressedEffect" style="border-radius: 20px; height: 25px; width: 70px" value="Submit" onclick="classicButtonSound()"/></td></tr>
    					</form>
    				</table>-->
    				<h1 id="SigninPageOpener" style="text-family: Comic sans MS;">SIGN IN</h1>
    				<p style="text-align: right; text-family: Comic sans MS;">Dont have an account yet?</p>
    			</div>
    			<!--<form method="get" action="signup.html">
    				<button class="button"><span>SIGNUP</span></button>
    			</form>
    			<input type="button" class="button" onclick="location.href='http://google.com';" value="Go to Google" />
    			<a class="button" href="signup.html">SIGNUP</a>-->
    			<button class="button" id="LoginPageOpener" style="text-family: Comic sans MS;">SIGNUP</button>
    		</div>
    	</div>

      <div id="mySidenav" class="sidenav">
				<?php
					//session_start();
					if(!isset($_SESSION['loggedin']))
					{
						echo '<section>
							<a class="dipper" id="closebtn" style="cursor: pointer;" onclick="closeNav()">&times;</a>
						</section>
<a href="Himanshu Database/signin.html">PLEASE LOG IN</a>';
					}
					else{
						echo '<section>
							<a class="dipper" id="closebtn" style="cursor: pointer;" onclick="closeNav()">&times;</a>
						</section>
						<a href="#"><img src="profpic.png"></img></a>
						<a href="Himanshu Database/signin.html">Welcome '.$_SESSION['user'].'</a>
						<a href="#">CONTACT</a>
						<a href="aboutPage.html">ABOUT</a>
						<a href="logout.php" style="position:absolute; bottom:80px;">LOGOUT</a>';
					}
				?>
      </div>

      <span  id="SideMenuBar" class="SideButton" style="font-size:50px; cursor:pointer; color: white; position: fixed; top: 50%;left: 0;" onclick="openNav()">&#187;</span>
    <!-------------------------------------------------------------------------->
		<p class="headings">Interior Designing</p>
		<div class="heading_divs" >
      <img class="heading_divs_img" style="border-radius: 20px; margin-left: 0px;" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs1.jpg" alt="Image not found"></img>
      <img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs2.jpg" alt="Image not found"></img>
      <img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs3.jpg" alt="Image not found"></img>
      <img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs4.jpg" alt="Image not found"></img>
      <img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs5.jpg" alt="Image not found"></img>
      <img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs6.jpg" alt="Image not found"></img>
		</div>
		<div id="container1" style="float: center;">
			<h1 id="fb" align="center"></h1>
			<div style="float: ;">
				<button style="position: relative; left: 45%" onclick="update()">Ask to PictoBlog</button>
			</div>
		</div>
		<div id="container"></div>
		<div id="view_img">
			<span class="close" style="cursor: pointer;">x</span>
			<img src="dark-artistic_00407341.jpg" alt="not found" />
			<img src="artistic-pictures-1.jpg" alt="" />
			<img src="background-paper.jpg" alt="" />
			<img src="Beautiful-Artistic-Photos-620x388.jpg" alt="" />
			<button class="button" id="AddImg" style="text-family: Comic sans MS; position:relative;left:-45%;">Add</button>
				</div>


    <!-------------------------------------------------------------------------------------------------->

    <script>
      function playThePopupSound(){
           var ThePopupSound = document.getElementById("ThePopupSound");
           ThePopupSound.play();
          }

      function playThePopupSoundclose(){
           var CloseSound = document.getElementById("CloseSound");
           CloseSound.play();
          }
      function classicButtonSound(){
           var classicButtonSound = document.getElementById("classicButtonSound");
           classicButtonSound.play();
          }


    /*------------------------------------------------------------------------------------------------*/

      function openNav() {
        document.getElementById("mySidenav").style.width = "20%";
        document.getElementById("SideMenuBar").style.visibility="collapse";transition="1s";
      }
      function closeNav() {
        document.getElementById("mySidenav").style.width = "0%";transition="0.5s";
        document.getElementById("SideMenuBar").style.visibility="inherit";
        var CloseSound = document.getElementById("CloseSound");
        CloseSound.play();
      }

    /*------------------------------------------------------------------------------------------------*/

      var LoginPopup = document.getElementById('myLoginPopup');
      var mainMenuProfile = document.getElementById("mainMenuProfile");
      //var sideMenuProfile = document.getElementById("sideMenuProfile");
      var span = document.getElementsByClassName("close");

      /*sideMenuProfile.onclick = function() {
          playThePopupSound();
          LoginPopup.style.display = "block";
      }*/

      mainMenuProfile.onclick = function() {
          playThePopupSound();
          LoginPopup.style.display = "block";
      }
			for(var j =0 ;j<span.length;++j)
      {span[j].onclick = function() {
          playThePopupSoundclose();
          LoginPopup.style.display = "none";
					document.querySelector('#view_img').style.display='none';
      }
}      window.onclick = function(event) {
          if (event.target == LoginPopup) {
              LoginPopup.style.display = "none";
          }
      }

    document.getElementById("LoginPageOpener").onclick = function()
    {
        location.href = "Himanshu Database/signup.html";
    };

    document.getElementById("SigninPageOpener").onclick = function()
    {
        location.href = "Himanshu Database/signin.html";
    };

    </script>


    <audio id="ThePopupSound" src="Gum_Bubble_Pop-Sound.mp3" ></audio>
    <audio id="CloseSound" src="click.mp3" ></audio>
    <audio id="classicButtonSound" src="Button Click Off.mp3" ></audio>
  </body>
</html>
