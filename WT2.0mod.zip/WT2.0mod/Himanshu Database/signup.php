<?php
include 'config.php';

$flag=0;
$dbname="test";
$db=mysql_select_db($dbname) or die(mysql_error());

$name=mysql_real_escape_string($_POST['name']);
$email=mysql_real_escape_string($_POST['email']);
$pass=md5($_POST['pass']);
$check="SELECT * FROM credentials WHERE name='$name' OR mail ='$email'";
$s=mysql_query($check);
$count=mysql_num_rows($s);
if($count!=0){

	header("Location:./signup.html");
}

$query="INSERT INTO credentials (name,mail,pass) VALUES ('$name','$email','$pass')";
$res=mysql_query($query) or die(mysql_error());
if($res)
	header("Location:./signin.html");
else {
	header("Location:./signup.html");
}
?>
<html>
<style>
body{

background-color:#959595;
animation:fade-in 2s;
}
a{
position:relative;
top:350px;
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
font-size:30px;
text-decoration:none;
color:black;
animation:fade-in 3.3s;
font-weight:lighter;
}
@keyframes fade-in{
from{opacity:0;}
to{opacity:1}
}
h1{
position:relative;
top:300px;

font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
		font-size:45px;
		font-weight:lighter;

}


</style>
<body>
<center><h1><?php echo($show) ?></h1></center>
<center><a href=<?php echo($where); ?> >Click here to   <?php echo($what);?> </a></center>
</body>


</html>
