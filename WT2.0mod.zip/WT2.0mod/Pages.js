<script>
function myFunction1() {
    document.getElementById("myDIV1").style.transition = "all 3s";
}
function myFunction2() {
    document.getElementById("myDIV2").style.transition = "all 3s";
}
function myFunction3() {
    document.getElementById("myDIV3").style.transition = "all 3s";
}
function myFunction4() {
    document.getElementById("myDIV4").style.transition = "all 3s";
}
function myFunction5() {
    document.getElementById("myDIV5").style.transition = "all 3s";
}
function myFunction6() {
    document.getElementById("myDIV6").style.transition = "all 3s";
}
function myFunction7() {
    document.getElementById("myDIV7").style.transition = "all 3s";
}
function myFunction8() {
    document.getElementById("myDIV8").style.transition = "all 3s";
}
function myFunction9() {
    document.getElementById("myDIV9").style.transition = "all 3s";
}
function myFunction10() {
    document.getElementById("myDIV10").style.transition = "all 3s";
}
</script>
