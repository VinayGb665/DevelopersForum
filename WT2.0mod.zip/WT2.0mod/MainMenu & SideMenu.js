<script>
  function playThePopupSound(){
       var ThePopupSound = document.getElementById("ThePopupSound");
       ThePopupSound.play();
      }

  function playThePopupSoundclose(){
       var CloseSound = document.getElementById("CloseSound");
       CloseSound.play();
      }
  function classicButtonSound(){
       var classicButtonSound = document.getElementById("classicButtonSound");
       classicButtonSound.play();
      }


/*------------------------------------------------------------------------------------------------*/

  function openNav() {
    document.getElementById("mySidenav").style.width = "20%";
    document.getElementById("SideMenuBar").style.visibility="collapse";transition="1s";
  }
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0%";transition="0.5s";
    document.getElementById("SideMenuBar").style.visibility="inherit";
    var CloseSound = document.getElementById("CloseSound");
    CloseSound.play();
  }

/*------------------------------------------------------------------------------------------------*/

  var LoginPopup = document.getElementById('myLoginPopup');
  var mainMenuProfile = document.getElementById("mainMenuProfile");
  //var sideMenuProfile = document.getElementById("sideMenuProfile");
  var span = document.getElementsByClassName("close")[0];

  /*sideMenuProfile.onclick = function() {
      playThePopupSound();
      LoginPopup.style.display = "block";
  }*/

  mainMenuProfile.onclick = function() {
      playThePopupSound();
      LoginPopup.style.display = "block";
  }
  span.onclick = function() {
      playThePopupSoundclose();
      LoginPopup.style.display = "none";
  }
  window.onclick = function(event) {
      if (event.target == LoginPopup) {
          LoginPopup.style.display = "none";
      }
  }

document.getElementById("LoginPageOpener").onclick = function()
{
    location.href = "Himanshu Database/signup.html";
};

document.getElementById("SigninPageOpener").onclick = function()
{
    location.href = "Himanshu Database/signin.html";
};

</script>
