<?php session_start(); ?>
<!DOCTYPE html>
<link rel="stylesheet" type="text/css" href="SideMenuBar.css"/>
<link rel="stylesheet" type="text/css" href="MainMenuBar.css"/>
<link rel="stylesheet" type="text/css" href="MovingText.css"/>
<!--<link rel="stylesheet" type="text/css" href="LoginPopup.css"/>-->
<!--<link rel="stylesheet" type="text/css" href="ButtonWithAnimation.css"/>-->

<html>
	<head>
		<style>
		::-webkit-scrollbar {
			display: none;
	}
		body{
			font-family: "Lato", sans-serif;
			background-color: black;
			background-repeat:no-repeat;
			background-size:100%;
			background-attachment: fixed;
			}

			.button {
			  display: inline-block;
			  border-radius: 15px 0px 15px 15px;
			  background-color: #1A5276;
			  border: none;
			  color: #FFFFFF;
			  text-align: center;
				float: right;
			  font-size: 20px;
			  padding: 1px;
				height: 50px;
			  width: 15%;
			  transition: all 0.5s;
			  cursor: pointer;
			  margin: 5px;
			}

			.button span {
			  cursor: pointer;
			  display: inline-block;
			  position: relative;
			  transition: 0.5s;
			}

			.button span:after {
			  content: '...';
			  position: absolute;
			  opacity: 0;
			  top: 0;
			  right: -30px;
			  transition: 0.5s;
			}

			.button:hover span {
			  padding-right: 25px;
			}

			.button:hover span:after {
			  opacity: 1;
			  right: 0;
			}
/*--------------------------------------------------------------------------*/

			.headings {
				padding-left: 20px;
				color: white;
				font-family: Comic Sans MS;
				font-size: 24px;
				text-shadow: 0 0 3px #1A5276;
			}
			.heading_divs {
				height: auto;
				width: 100%;
				padding: 10px;
				background-color: #1A5276;
				border-radius: 20px;
			}

			.heading_divs_img {
				margin-left: 5px;
			  border: 1px solid black;
			}

			.heading_divs_img:hover, .headings:hover {
				cursor: pointer;
				opacity: 0.8;
			}

/*--------------------------------------------------------------------------*/
			.buttonPressedEffect {
			  padding: 2px 10px;
			  cursor: pointer;
			  text-align: center;
			  text-decoration: none;
			  outline: none;
			  color: #fff;
			  background-color: #1A5276;
			  border: none;
			  border-radius: 15px;
			  box-shadow: 0 3px #999;
			}

			.buttonPressedEffect:hover {background-color: #3e8e41}

			.buttonPressedEffect:active {
			  background-color: #3e8e41;
			  box-shadow: 1px 1px #666;
			  transform: translateY(4px);
			}

/*--------------------------------------------------------------------------*/

			.LoginPopup {
					display: none; /* Hidden by default */
					position: fixed; /* Stay in place */
					z-index: 1; /* Sit on top */
					padding-top: 100px; /* Location of the box */
					left: 0;
					top: 0;
					width: 100%; /* Full width */
					height: 100%; /* Full height */
					overflow: auto; /* Enable scroll if needed */
					background-color: rgb(0,0,0); /* Fallback color */
					background-color: rgba(0,0,0,0.5); /* Black w/ opacity */
			}

			.LoginPopup-content {
					position: relative;
					background-color: #fefefe;
					border-radius: 25px 25px 0px 25px;
					margin: auto;
					padding: 0;
					border: 1px solid #888;
					width: 80%;
					box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
					-webkit-animation-name: animatetop;
					-webkit-animation-duration: 0.6s;
					animation-name: animatetop;
					animation-duration: 0.6s
			}
			@-webkit-keyframes animatetop {
					from {top:-300px; opacity:0}
					to {top:0; opacity:1}
			}

			@keyframes animatetop {
					from {top:-300px; opacity:0}
					to {top:0; opacity:1}
			}
			.close {
					color: white;
					float: right;
					font-size: 28px;
					font-weight: bold;
			}

			.close:hover,
			.close:focus {
					color: #000;
					text-decoration: none;
					cursor: pointer;
			}

			.LoginPopup-header {
					border-radius: 25px 25px 0px 0px;
					padding: 2px 16px;
					background-color: #1A5276;
					color: white;
			}

			.LoginPopup-body {
					border-radius: 0px;
					padding: 20px;
			}

/*--------------------------------------------------------------------------*/


			div.moving_text {
				font-family:"Ordnung";;
				font-weight: bold;
				font-size: 27px;
				width: 190px;
				position: relative;
				-webkit-animation: MoveLogoText 5s infinite;
				animation: MoveLogoText 20s infinite;
				animation-timing-function: linear;
			}

			@keyframes MoveLogoText {
				from {left: -190px;}
				to {left: 100%;}
				0%   { color: orange;}
				25%  { color: white;}
				50%  { color: blue;}
				75%  { color: white;}
				100% { color: green;}
			}

			div.moving_text:hover {
				animation-play-state: paused;
			}
/*--------------------------------------------------------------------------*/

			#SigninPageOpener:hover {
				cursor: pointer;
			}
		</style>
	</head>

<!-------------------------------------------------------------------------->
	<body>
	<div class="menubartype">
		<ul class="menubar">
			<li class="menubar_li"><a class="menubar_li_a" href="#home">HOME</a></li>
			<li class="menubar_li"><a class="menubar_li_a" id="mainMenuProfile">PROFILE</a></li>
			<!--<button id="myBtn" class="button" style="vertical-align:middle"><span>PROFILE</span></button>-->
			<li class="menubar_li"><a class="menubar_li_a" href="3D Trekking.html">CONTACT</a></li>
			<li class="menubar_li"><a class="menubar_li_a" href="aboutPage.html">ABOUT</a></li>
		</ul>
	</div>

<!-------------------------------------------------------------------------->

	<div class="moving_text">PictoBlog</div>

	<div id="myLoginPopup" class="LoginPopup">

		<!-- LoginPopup content -->
		<div class="LoginPopup-content">
			<div class="LoginPopup-header">
				<span class="close" style="cursor: pointer;">x</span>
				<h2 style="text-align:center;">LOGIN</h2>
			</div>
			<div class="LoginPopup-body">
				<!--<table style="padding-top: 3%; padding-bottom:3%; padding-left:20%">
					<form action="" method="post">
							<tr>
								<td style="padding-right: 50px;">USERNAME</td><td><input type="text" name="username" size="25" maxlength="20" placeholder="required" style="font-size:12pt;height:25px;width:200px;" required/></td>
							</tr>
							<tr>
								<td style="padding-right: 50px;">PASSWORD</td><td><input type="password" name="password" size="25" maxlength="20" placeholder="required" style="font-size:12pt;height:25px;width:200px;" required/></td><td style="padding-left: 50px;"><a style="font-size: 0.5em;" href="">Forgot Password?</a></td>
							</tr>
							<tr><td style="padding-top: 25px;"><input type="submit" class="buttonPressedEffect" style="border-radius: 20px; height: 25px; width: 70px" value="Submit" onclick="classicButtonSound()"/></td></tr>
					</form>
				</table>-->
				<h1 id="SigninPageOpener" style="text-family: Comic sans MS;">Come On. <br>SIGN IN</h1>
				<p style="text-align: right; text-family: Comic sans MS;">Dont have an account yet?</p>
			</div>
			<!--<form method="get" action="signup.html">
				<button class="button"><span>SIGNUP</span></button>
			</form>
			<input type="button" class="button" onclick="location.href='http://google.com';" value="Go to Google" />
			<a class="button" href="signup.html">SIGNUP</a>-->
			<button class="button" id="LoginPageOpener" style="text-family: Comic sans MS;">SIGNUP</button>
		</div>

	</div>

<!-------------------------------------------------------------------------->

	<div><br/>
	</div>
		<div id="mySidenav" class="sidenav">
				<?php
					//session_start();
					if(!isset($_SESSION['loggedin']))
					{
						echo '<section>
							<a class="dipper" id="closebtn" style="cursor: pointer;" onclick="closeNav()">&times;</a>
						</section>
<a href="Himanshu Database/signin.html">PLEASE LOG IN</a>';
					}
					else{
						echo '<section>
							<a class="dipper" id="closebtn" style="cursor: pointer;" onclick="closeNav()">&times;</a>
						</section>
					  <a href="#"><img src="profpic.png"></img></a>
					  <a href="Himanshu Database/signin.html">Welcome '.$_SESSION['user'].'</a>
					  <a href="#">CONTACT</a>
					  <a href="aboutPage.html">ABOUT</a>
						<a href="logout.php" style="position:absolute; bottom:80px;">LOGOUT</a>';
					}
				?>
		</div>
			<span  id="SideMenuBar" class="SideButton" style="font-size:50px; cursor:pointer; color: white; position: fixed; top: 50%;left: 0;" onclick="openNav()">&#187;</span>
			<div class="i_fra" style="float:center; scroll:no; width:100%; border-width:0px; border-style:outset; border-color:;">
			<iframe style="border:none;" height="380px" width="99%" src="jQuery-Waterwheel-Carousel/waterwheelcarousel.html" alt="Nothing to display" name="Page2Demo" scrolling="no" frameborder="0"></iframe>
			</div>
			<p class="headings" onclick="goToArchitecture()">Arcitecture</p>
			<div class="heading_divs">
				<img class="heading_divs_img" style="border-radius: 20px; margin-left: 0px;" height="200px" width="200px" src="Architecture Photos/architectural-designs2.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Architecture Photos/architectural-designs1.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Architecture Photos/architectural-designs3.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Architecture Photos/architectural-designs4.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Architecture Photos/architectural-designs5.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Architecture Photos/architectural-designs6.jpg" alt="Image not found"></img>
			</div>
			<p class="headings" onclick="goToWallPaintings()">Wall Paintings</p>
			<div class="heading_divs" >
				<img class="heading_divs_img" style="border-radius: 20px; margin-left: 0px;" height="200px" width="200px" src="Wall Painting Photos/wall_painting1.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Wall Painting Photos/wall_painting2.png" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Wall Painting Photos/wall_painting3.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Wall Painting Photos/wall_painting4.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Wall Painting Photos/wall_painting5.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Wall Painting Photos/wall_painting6.jpg" alt="Image not found"></img>
			</div>
			<p class="headings" onclick="goToInteriorDesigning()">Interior Designing</p>
			<div class="heading_divs">
				<img class="heading_divs_img" style="border-radius: 20px; margin-left: 0px;" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs1.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs2.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs3.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs4.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs5.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Interior Designing Photos/Interior_Designs6.jpg" alt="Image not found"></img>
			</div>
			<p class="headings" onclick="goToFashion()">Fashion</p>
			<div class="heading_divs">
				<img class="heading_divs_img" style="border-radius: 20px; margin-left: 0px;" height="200px" width="200px" src="Fashion Photos/Fashion1.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Fashion Photos/Fashion2.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Fashion Photos/Fashion3.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Fashion Photos/Fashion4.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Fashion Photos/Fashion5.jpg" alt="Image not found"></img>
				<img class="heading_divs_img" style="border-radius: 20px" height="200px" width="200px" src="Fashion Photos/Fashion6.jpg" alt="Image not found"></img>
			</div></br>
		<<!--<div class="i_fra" style="float:center; width:100%; border-width:0px; border-style:outset; border-color: white;">
			<iframe style="padding-left: 7px;" height="500px" width="99%" src="/Users/SUNSEEMA/Documents/College/html/Final Project/WT2.0/FastHoverSlideshow/index2.html" alt="Nothing to display" name="Page2Demo" frameborder="0px solid black"></iframe>
		</div>-->
			<!--<div class="i_fra" style="float:center; width:100%; border-width:0px; border-style:outset; border-color:;">
			<iframe style="border:none;" height="500px" width="99%" src="" alt="Nothing to display" name="Page2Demo" frameborder="0"></iframe>-->

<!----------------------------------------------------------------------------------------------------------------------------------------------------------->

		<script>
			function playThePopupSound(){
			     var ThePopupSound = document.getElementById("ThePopupSound");
			     ThePopupSound.play();
			    }

			function playThePopupSoundclose(){
		       var CloseSound = document.getElementById("CloseSound");
		       CloseSound.play();
		  		}
			function classicButtonSound(){
		       var classicButtonSound = document.getElementById("classicButtonSound");
		       classicButtonSound.play();
		  		}


/*------------------------------------------------------------------------------------------------*/

			function openNav() {
				document.getElementById("mySidenav").style.width = "20%";
				document.getElementById("SideMenuBar").style.visibility="collapse";transition="1s";
			}
			function closeNav() {
				document.getElementById("mySidenav").style.width = "0%";transition="0.5s";
				document.getElementById("SideMenuBar").style.visibility="inherit";
				var CloseSound = document.getElementById("CloseSound");
				CloseSound.play();
			}

/*------------------------------------------------------------------------------------------------*/

			var LoginPopup = document.getElementById('myLoginPopup');
			var mainMenuProfile = document.getElementById("mainMenuProfile");
			//var sideMenuProfile = document.getElementById("sideMenuProfile");
			var span = document.getElementsByClassName("close")[0];

			/*sideMenuProfile.onclick = function() {
					playThePopupSound();
					LoginPopup.style.display = "block";
			}*/

			mainMenuProfile.onclick = function() {
				  playThePopupSound();
					LoginPopup.style.display = "block";
			}
			span.onclick = function() {
					playThePopupSoundclose();
					LoginPopup.style.display = "none";
			}
			window.onclick = function(event) {
					if (event.target == LoginPopup) {
							LoginPopup.style.display = "none";
					}
			}
		</script>
		<script type="text/javascript">
		document.getElementById("LoginPageOpener").onclick = function()
		{
        location.href = "Himanshu Database/signup.html";
    };

		document.getElementById("SigninPageOpener").onclick = function()
		{
				location.href = "Himanshu Database/signin.html";
		};

//---------------------------------------------------------------------------

		function goToArchitecture()
		{
			location.href = "ArchitecturePage.php";
		}
		function goToWallPaintings()
		{
			location.href = "WallPaintings Page.html";
		}
		function goToInteriorDesigning()
		{
			location.href = "InteriorDesigning Page.php";
		}
		function goToFashion()
		{
			location.href = "Fashion Page.php";
		}

//---------------------------------------------------------------------------
		</script>

		<!--<script src="http://code.jquery.com/jquery-2.1.3.min.js"></script>
		<script src="jquery.waypoints.min.js"></script>
		<script src="waypoint.js"></script>-->

		<audio id="ThePopupSound" src="Gum_Bubble_Pop-Sound.mp3" ></audio>
		<audio id="CloseSound" src="click.mp3" ></audio>
		<audio id="classicButtonSound" src="Button Click Off.mp3" ></audio>

	</body>
</html>
